************ Read Me ****************
///หมายเหตุ
1.ไฟล์ database ชื่่อ SQL_ร้านครัวคุณพล.sql
2.Folder เว็บไซต์ร้าน ชื่อ krua_khun_phon

///วิธีการ Import ฐานข้อมูล
1. เข้า url: localhost/phpmyadmin
2. เลือก New และตั้งชื่อฐานข้อมูลเป็น KRUAKHUNPHON ตั้งค่าเป็น utf8_unicode_ci และกด Create
3. ไปที่แท็บ Import แล้ว Choose file โดยเข้าไปที่โฟลเดอร์  Project_Group16 เลือกไฟล์ KRUAKHUNPHON.sql และกด
Go

///วิธีการเปิดหน้า Website 
1. นำFolder เว็บไซต์ร้าน ชื่อ krua_khun_phon ไปใส่ใน ไดรฟ์ C: /xampp/htdocs/
2. เปิด xampp control panel
3. คลิก start Apache และ MySQL
4. เข้าเว็บเบราเซอร์
5. พิมพ์ http://localhost/krua_khun_phon/wordpress


